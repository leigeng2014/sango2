define('ace/snippets/matlab', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "matlab";

});
